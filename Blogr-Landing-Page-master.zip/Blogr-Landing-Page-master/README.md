# Junior Implementation Specialist - Coding Challenge

To get started with this challenge, download the files by clicking on Code, then download Zip. Then create your own repository within your own account.

Once you've completed the tasks from the doc and you're happy with your code, upload the files to your repository by clicking on the "Add file" button and select "Upload files".

For us to be able to see your work, we'll need you to host this on github pages. To do this, go into the repository settings, then pages. Within pages, select the drop down and select "Master" and click save. 
